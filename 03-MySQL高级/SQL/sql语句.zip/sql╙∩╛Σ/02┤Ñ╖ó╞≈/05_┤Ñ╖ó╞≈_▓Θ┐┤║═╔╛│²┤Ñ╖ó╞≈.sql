/*
	查看触发器
	SHOW TRIGGERS;
*/
-- 查看触发器
SHOW TRIGGERS;


/*
	删除触发器
	DROP TRIGGER 触发器名称;
*/
-- 删除account_delete触发器
DROP TRIGGER account_delete;