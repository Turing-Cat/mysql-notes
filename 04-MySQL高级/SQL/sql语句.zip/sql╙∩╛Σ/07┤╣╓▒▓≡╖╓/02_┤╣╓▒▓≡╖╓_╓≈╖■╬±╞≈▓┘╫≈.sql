-- 创建db4和db5数据库，从服务器会自动同步
CREATE DATABASE db4;
CREATE DATABASE db5;

-- 查询dog表
SELECT * FROM dog;
-- 查询cat表
SELECT * FROM cat;


-- 查询apple表
SELECT * FROM apple;
-- 查询banana表
SELECT * FROM banana;