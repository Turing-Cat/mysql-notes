-- 创建db2和db3数据库，从服务器会自动同步
CREATE DATABASE db2;
CREATE DATABASE db3;

-- 查询不同数据库中的product表
SELECT * FROM product;