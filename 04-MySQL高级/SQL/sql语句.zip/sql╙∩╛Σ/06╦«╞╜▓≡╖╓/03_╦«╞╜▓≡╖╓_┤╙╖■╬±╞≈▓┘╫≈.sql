-- 查询不同数据库中的product表
SELECT * FROM product;