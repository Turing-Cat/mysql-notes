-- 主服务器：查询学生表，可以看到数据
SELECT * FROM student;